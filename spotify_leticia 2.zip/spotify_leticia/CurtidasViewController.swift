//
//  CurtidasViewController.swift
//  spotify_leticia
//
//  Created by COTEMIG on 01/07/25.
//

import UIKit
struct MusicData{
    let nome: String
    let artista: String
}

class CurtidasViewController: UIViewController, UITableViewDataSource {
    
    let musicList : [MusicData]=[
        MusicData(nome: "Amarelo", artista: "Lana"),
        MusicData(nome: "Laranja", artista: "DelRey" )
     ]
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return musicList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier:"musicCell") as? MusicTableViewCell else{
                    fatalError("Não foi encontrado")
                }
        cell.configure(musicData: musicList[indexPath.item])
                return cell
    }
    

    @IBOutlet weak var tableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        tableView.dataSource = self
        
    }


        

}

    


